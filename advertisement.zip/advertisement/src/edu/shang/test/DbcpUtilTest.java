//package edu.shang.test;
//
//import static org.junit.Assert.*;
//
//import java.sql.Connection;
//import java.sql.SQLException;
//
//import org.junit.Test;
//
//import edu.shang.dao.DbcpUtil;
//
//public class DbcpUtilTest {
//
//	@Test
//	public void testGetConnection() {
//		try {
//			Connection connection=DbcpUtil.getConnection();
//			System.out.println(connection);
//			if(connection!=null)
//				DbcpUtil.release(connection);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	@Test
//	public void testRelease() {
//		fail("Not yet implemented");
//	}
//	@Test
//	public void testGetConnection2() throws Exception {
//		try {
//			Connection connection=DbcpUtil.getConnection2();
//			System.out.println(connection);
//			if(connection!=null)
//				DbcpUtil.release(connection);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//}

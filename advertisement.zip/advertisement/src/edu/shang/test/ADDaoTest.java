package edu.shang.test;

import org.junit.Test;

import edu.shang.bean.MemberInform;
import edu.shang.bean.Register;
import edu.shang.dao.ADDao;

public class ADDaoTest {

	@Test
	public void testAdd() {
		Register register=new Register("zhang", "2333", "likeuu", null, null, null, null);
		ADDao dao=new ADDao();
		int m=dao.add(register);
		System.out.println(m);
		}
	@Test
	public void testSelect() {
		ADDao dao=new ADDao();
		MemberInform info=dao.select1("xiaolin");
		if(info!=null)
		System.out.println(info.getEmail());
		else
			System.out.println("不存在");
		}
	@Test
	public void testSelect2() {
		ADDao dao=new ADDao();
		int m=dao.select("zhang","123");
		System.out.println(m);
		}
	@Test
	public void testUpdate() {
		ADDao dao=new ADDao();
		String sql="update member set advertiseTitle=?,phone=?,email=?,message=? where logname=?";
		int m=dao.update(sql, "13","2222","256","nihao","zhang");
		System.out.println(m);
		}
}

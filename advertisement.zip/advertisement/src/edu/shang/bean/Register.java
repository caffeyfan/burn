package edu.shang.bean;

public class Register {
	private String logname;//
	private String password;
	private String advertiseTitle;//广告标题
	private String phone;
	private String email;
	private String message;//广告词
	private String pic;
	public Register(String logname, String password, String advertiseTitle, String phone, String email, String message,
			String pic) {
		super();
		this.logname = logname;
		this.password = password;
		this.advertiseTitle = advertiseTitle;
		this.phone = phone;
		this.email = email;
		this.message = message;
		this.pic = pic;
	}
	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getLogname() {
		return logname;
	}
	public void setLogname(String logname) {
		this.logname = logname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAdvertiseTitle() {
		return advertiseTitle;
	}
	public void setAdvertiseTitle(String advertiseTitle) {
		this.advertiseTitle = advertiseTitle;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	
}

package edu.shang.bean;

public class Login {
	private String logname;
	private String password;
	private boolean  success;
	public Login(String logname, String password,boolean success) {
		super();
		this.logname = logname;
		this.password = password;
		this.success =success;
	}
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getLogname() {
		return logname;
	}
	public void setLogname(String logname) {
		this.logname = logname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean getSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
}

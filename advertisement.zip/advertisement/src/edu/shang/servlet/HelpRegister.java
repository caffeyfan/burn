package edu.shang.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.shang.bean.Register;
import edu.shang.dao.ADDao;

/**
 * Servlet implementation class HelpRegister
 */
@WebServlet("/helpRegister")
public class HelpRegister extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private ADDao dao=new ADDao();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setContentType("html/text");
		request.setCharacterEncoding("utf-8");
		Register reg=null;
		int m=0;
		String pic="p.jpg";
		String logname=request.getParameter("logname").trim();
		String password=request.getParameter("password").trim();
		String advertiseTitle=request.getParameter("advertiseTitle").trim();
		String email=request.getParameter("email").trim();
		String phone=request.getParameter("phone").trim();
		String message=request.getParameter("message"); //从 request 中提取用户提交的信息
		if(logname==null)
		logname="";
		if(password==null)
		password="";
		boolean isLD=true;
		for(int i=0;i<logname.length();i++) //for 循环用来判断 logname 中组成是不是字
		{ char c=logname.charAt(i);
		if(!((c<='z'&&c>='a')||(c<='Z'&&c>='A')||(c<='9'&&c>='0')))
		isLD=false;
		}
		boolean boo=logname.length()>0&&password.length()>0&&isLD; //定义 boo,当 logname 和
		String backNews="";
		reg=new Register(logname, password, advertiseTitle, phone, email, message, pic);
		if(boo) {
			System.out.println("boo"+boo);
			//判断数据库中是否有重复记录
			if(dao.select(logname).size()>0) {
				backNews="该用户名已被注册过";
			}else {
				//没有重复记录
				m=dao.add(reg);
			}
			System.out.println(m);
			if(m!=0){ 
				backNews="注册成功";
			}
		}else{ 
			backNews="信息填写不完整或名字中有非法字符"; //当 logname 信息不
		}
		request.setAttribute("register",reg); //给 request 增加了一个属性
		request.setAttribute("backnews", backNews);
		request.getRequestDispatcher("/showRegisterMess.jsp").forward(request, response);
}

}

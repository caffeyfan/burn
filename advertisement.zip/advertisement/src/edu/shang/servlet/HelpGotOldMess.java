package edu.shang.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.shang.bean.Login;
import edu.shang.bean.Register;
import edu.shang.dao.ADDao;

/**
 * Servlet implementation class HelpGotOldMess
 */
@WebServlet("/helpGotOldMess")
public class HelpGotOldMess extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//确认是否登录，
		//没登录重定向到登录界面
		HttpSession session=request.getSession(true);
		Login login=(Login)session.getAttribute("login");
		if(login==null) {
			response.sendRedirect("login.jsp");
		}else {
			String logname=login.getLogname();
			doContinue(request,response,logname);
		}
		//登录显示以前的信息
	}


	private void doContinue(HttpServletRequest request, HttpServletResponse response, String logname) throws ServletException, IOException {
		Register register=null;
		ADDao dao=new ADDao();
		List<Register> list=dao.select(logname);
		System.out.println(logname);
		System.out.println(list.size()+"size");
		if(list.size()>0) {
			register=list.get(0);
			request.setAttribute("register", register);
			System.out.println(register.getLogname());
			request.getRequestDispatcher("inputModifyMess.jsp").forward(request, response);
		}
	}

}

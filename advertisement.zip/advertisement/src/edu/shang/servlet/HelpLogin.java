package edu.shang.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.shang.bean.Login;
import edu.shang.dao.ADDao;

/**
 * Servlet implementation class HelpLogin
 */
@WebServlet("/helpLogin")
public class HelpLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setContentType("html/text");
		String backNews="";
		String logname=request.getParameter("logname").trim();
		String password=request.getParameter("password").trim();
		//判斷當前用戶是否在使用,通過session對象，如果對象里有loginbean屬性，說明該用戶
		//正在使用，如果沒有loginbean，就添加該屬性
		Login loginbean=null;
		HttpSession session=request.getSession(true);
		try {
			loginbean=(Login)session.getAttribute("login");
			if(loginbean==null) {
				loginbean =new Login();
				System.out.println(loginbean.getLogname());
				session.setAttribute("login",loginbean);
			}
		} catch (Exception e) {
			loginbean =new Login();
			session.setAttribute("login",loginbean);
			e.printStackTrace();
		}
		
		//判断是否是用戶或者已經登陸的用戶
		boolean ok=loginbean.getSuccess();
		if(ok==true&&logname.equals(loginbean.getLogname())&&password.equals(loginbean.getPassword())) {
			backNews= logname+"已经登录了";
			
		}else {
			ADDao dao=new ADDao();
			int m=dao.select(logname, password);
			if(m>0) {
				backNews="登陆成功";
				loginbean.setLogname(logname);
				loginbean.setPassword(password);
				loginbean.setSuccess(true);
			}else {
				loginbean.setSuccess(false);
				loginbean.setLogname(logname);
				loginbean.setPassword(password);
				backNews="您输入的用户名不存在，或密码不般配";
			}
		}
		request.setAttribute("back", backNews);
		session.setAttribute("login",loginbean);
		request.getRequestDispatcher("login.jsp").forward(request, response);
		//不是，则返回等路页面，返回您登录的信息有误
	}

}

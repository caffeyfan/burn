package edu.shang.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.CachedRowSet;

import com.sun.rowset.CachedRowSetImpl;

import edu.shang.bean.Login;
import edu.shang.bean.MemberInform;
import edu.shang.bean.ShowByPage;
import edu.shang.dao.ADDao;


@WebServlet("/helpShowMember")
public class HelpShowMember extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CachedRowSetImpl rowSet=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		Login login = (Login) session.getAttribute("login"); // 获取用户登录时的Javabean
		boolean ok = true;
		if (login == null) {
			ok = false;
			response.sendRedirect("login.jsp"); // 重定向到登录页面
		}
		if (ok == true) {
			try {
				continueDoGet(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private void continueDoGet(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		MemberInform inform = null;
		//request.setAttribute("inform", inform);
		String logname = request.getParameter("logname");
		ADDao dao = new ADDao();
		inform = dao.select1(logname);
		if(inform!=null)
		System.out.println(inform.getLogname());
		request.setAttribute("inform", inform);
		try {
			request.getRequestDispatcher("showLookedMember.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			inform.setBackNews(""+e);System.out.println("ok1"+e);
		} 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		Login login = (Login) session.getAttribute("login");
		if (login == null) {
			response.sendRedirect("login.jsp");
		} else {
			try {
				doContinue(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void doContinue(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		HttpSession session = request.getSession(true);
		StringBuffer presentPageResult = new StringBuffer();
		ShowByPage showBean = null;
		try {
			showBean = (ShowByPage) session.getAttribute("show");
			if (showBean == null) {
				showBean = new ShowByPage();
				session.setAttribute("show", showBean);
			}
		} catch (Exception e) {
			showBean = new ShowByPage();
			session.setAttribute("show", showBean);
		}
		showBean.setPageSize(3);
		int showpage = Integer.parseInt(request.getParameter("showPage"));
		if (showpage > showBean.getPageAllCount())
			showpage = 1;
		if (showpage <= 0)
			showpage = showBean.getPageAllCount();
		showBean.setShowPage(showpage);
		int pagesize = showBean.getPageSize();
		
		
		//rowSet = new CachedRowSetImpl();
		ADDao dao = new ADDao();
		rowSet = dao.select();
		//System.out.println(rs);
		//rowSet.populate(rs);
		showBean.setRowSet(rowSet);
		rowSet.last();
		int m = rowSet.getRow();
		int n = pagesize;
		int pageAllCount = ((m % n) == 0) ? (m / n) : (m / n + 1);
		showBean.setPageAllCount(pageAllCount);// 数据存储在showBean中
		presentPageResult = show(showpage, pagesize, rowSet);
		showBean.setPresentPageResult(presentPageResult);
		System.out.println(m+n);
		try {
			request.getRequestDispatcher("showAllMember.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//rs.close();
	}

	private StringBuffer show(int page, int pagesize, CachedRowSet rowSet2) {
		StringBuffer str = new StringBuffer();
		try {
			rowSet.absolute((page - 1) * pagesize + 1);
			for (int i = 1; i <= pagesize; i++) {
				str.append("<tr>");
				str.append("<td>" + rowSet.getString(1) + "</td>");
				str.append("<td>" + rowSet.getString(3) + "</td>");
				str.append("<td>" + rowSet.getString(4) + "</td>");
				str.append("<td>" + rowSet.getString(5) + "</td>");
				str.append("<td>" + rowSet.getString(6) + "</td>");
				String s = "<img src=image/" + rowSet.getString(7) + " width=100 height=100/>";
				str.append("<td>" + s + "</td>");
				str.append("</tr>");
				rowSet.next();
			}
		} catch (SQLException exp) {
		}
		return str;
	}

}

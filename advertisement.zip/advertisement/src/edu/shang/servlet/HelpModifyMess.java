package edu.shang.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.shang.bean.Login;
import edu.shang.dao.ADDao;

/**
 * Servlet implementation class HelpModifyMess
 */
@WebServlet("/helpModifyMess")
public class HelpModifyMess extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String advertiseTile=request.getParameter("newAdvertiseTitle");
		String newphone=request.getParameter("newPhone").trim();
		String newEmail=request.getParameter("newEmail").trim();
		String newMessage=request.getParameter("newMessage");
		HttpSession session=request.getSession(true);
		Login login=(Login)session.getAttribute("login");
		String backnews="";
		String logname=null;
		if(login!=null) {
			logname=login.getLogname();
		}else {
			response.sendRedirect("login.jsp");
		}
		
		ADDao dao=new ADDao();
		String sql="update member set advertiseTitle=?,phone=?,email=?,message=? where logname=?";
		int m=dao.update(sql, advertiseTile,newphone,newEmail,newMessage,logname);
		if(m>0) {
			backnews="修改成功";

		}else {
			backnews="修改失败;请重新填写完整信息";
		}
		request.setAttribute("backnews", backnews);
		request.getRequestDispatcher("showModifyMess.jsp").forward(request, response);
	}

}

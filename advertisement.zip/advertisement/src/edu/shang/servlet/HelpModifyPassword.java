package edu.shang.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.shang.bean.Login;
import edu.shang.dao.ADDao;

/**
 * Servlet implementation class HelpModifyPassword
 */
@WebServlet("/helpModifyPassword")
public class HelpModifyPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//先判断用户是否登录
		//若登录获取其密码
		//没登录，转到登录页面
		HttpSession session=request.getSession(true);
		Login login=(Login)session.getAttribute("login");
		if(login==null) {
			response.sendRedirect("login.jsp");
		}else {
			String logname=login.getLogname();
			System.out.println("logname"+logname);
			continueWork(request,response,logname);
		}
	}
	private void continueWork(HttpServletRequest request, HttpServletResponse response, String logname) throws ServletException, IOException {
		String oldPassword=request.getParameter("oldPassword");
		String newPassword=request.getParameter("newPassword");
		String backnews="";
		ADDao dao=new ADDao();
		String sql="update member set password=? where logname=?";
		//是否存在该用户
		int m=dao.select(logname, oldPassword);
		if(m>0) {
			int mm=dao.update(sql,newPassword,logname);
			if(mm>0) {
				backnews="密码修改成功";
				response.sendRedirect("success.jsp");
				return;
			}else {
				backnews="密码更新失败";
			}
		}else {
			backnews = "密码更新失败,您的旧密码填写有误";
		}
		request.setAttribute("backnews", backnews);
		request.getRequestDispatcher("modifyPassword.jsp").forward(request, response);
	}

}

package edu.shang.dao;
//使用DBCP数据库连接池,使用的是basicdatasource

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbcp.BasicDataSourceFactory;

public class DbcpUtil {
	private static BasicDataSource datasource=null;
	static {
		//1初始化datasource
		datasource=new BasicDataSource();
		
	}
	public static Connection getConnection() throws SQLException {
		//设置驱动
		datasource.setDriverClassName("com.mysql.jdbc.Driver");
		//设置URL
	datasource.setUrl("jdbc:mysql://gz-cdb-k0gmkrqv.sql.tencentcdb.com:63375/she");
	//设置用户名
		datasource.setUsername("root");
		datasource.setPassword("Sk15353430089%");
		//设置密码
		//初始化了连接池的数量
		datasource.setInitialSize(10);
		//设置最大连接数，同一时间可以向数据库申请的连接数
		datasource.setMaxActive(5);
		//设置最小连接数
		datasource.setMinIdle(2);
		//设置等待数据库分配连接的时间，超时会抛出异常,3s
		datasource.setMaxWait(1000*3);
		
		//2获取连接
		Connection connection=datasource.getConnection();
		return connection;
	}
	
	//最长使用的方法是使用配置文件，读取配置文件相关信息，有利于修改
	public static Connection getConnection2() throws Exception {
		Connection conn=null;
		//创建DataSource
		
		Properties properties=new Properties();
		InputStream isInputStream=DbcpUtil.class.getClassLoader().getResourceAsStream("edu/shang/dao/dbcp.properties");
		properties.load(isInputStream);
		BasicDataSource datasource1=(BasicDataSource) BasicDataSourceFactory.createDataSource(properties);
		conn=datasource1.getConnection();
		
	
		return conn;
	}
	public static void release(Connection connection) {
		try {
			if(connection!=null) {
				connection.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package edu.shang.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.shang.bean.MemberInform;
import edu.shang.bean.Register;
import com.sun.rowset.CachedRowSetImpl;
 
public class ADDao {
	
	public int add(Register r) {
		Connection connection = null;
		PreparedStatement ps = null;
		int tag = -1;
		String sql = "insert into member values(?,?,?,?,?,?,?)";
		System.out.println(sql);
		try {
			connection =DbcpUtil.getConnection();
			ps = connection.prepareStatement(sql);
			ps.setString(1, r.getLogname());
			ps.setString(2, r.getPassword());
			ps.setString(3, r.getAdvertiseTitle());
			ps.setString(4, r.getPhone());
			ps.setString(5, r.getEmail());
			ps.setString(6, r.getMessage());
			ps.setString(7, r.getPic());
			tag = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return tag;

	}
	public CachedRowSetImpl select() {
		CachedRowSetImpl rowset=null;
		ResultSet rs = null;
		Connection connection = null;
		PreparedStatement ps = null;
		String sql = "select * from member";
		try {
			connection = DbcpUtil.getConnection();
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			rowset=new CachedRowSetImpl();
			rowset.populate(rs);
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					
					if (ps != null)
						ps.close();
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				}
		return rowset;
	}
	public MemberInform select1(String logname) {
		ResultSet rs = null;
		Connection connection = null;
		PreparedStatement ps = null;
		String sql = "select * from member where logname=?";
		MemberInform inform = null;
		try {
			connection = DbcpUtil.getConnection();
			ps = connection.prepareStatement(sql);
			ps.setString(1, logname);
			rs = ps.executeQuery();
			if(rs.next()) {
				inform = new MemberInform();
				inform.setLogname(rs.getString(1));
				inform.setAdvertiseTitle(rs.getString(3));
				inform.setPhone(rs.getString(4));
				inform.setEmail(rs.getString(5));
				inform.setMessage(rs.getString(6));
				inform.setPic(rs.getString(7));
				inform.setBackNews("查询到的会员信息：");
			}
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if (rs != null)
						rs.close();
					if (ps != null)
						ps.close();
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				}
		return inform;
	}
	public List<Register>select(String name) {
		ResultSet rs = null;
		Connection connection = null;
		PreparedStatement ps = null;
		List<Register> list=new ArrayList<>();
		int m = 0;
		String sql = "select * from member where logname=?";
		System.out.println(sql);
		try {
			connection = DbcpUtil.getConnection();
			ps = connection.prepareStatement(sql);
			ps.setString(1, name);
			rs = ps.executeQuery();
			if (rs != null) {
				while(rs.next()) {
					Register register=new Register();
					register.setLogname(rs.getString(1));
					register.setPassword(rs.getString(2));
					register.setAdvertiseTitle(rs.getString(3));
					register.setPhone(rs.getString(4));
					register.setEmail(rs.getString(5));
					register.setPic(rs.getString(6));
					register.setMessage(rs.getString(7));
					list.add(register);
					m++;
				}
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println("m" + "..." + m);
		
		return list;
	}
	public int select(String name,String password) {
		Connection connection=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int m=0;
		String sql = "select * from member where logname=? and password=?";
		System.out.println(sql);
		try {
			connection = DbcpUtil.getConnection();
			ps = connection.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2,password);
			rs = ps.executeQuery();
			if (rs.next()) {
				m++;
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println("m" + "..." + m);

		return m;
	}
	public int update(String sql,Object...obj) {
	
		Connection connection = null;
		PreparedStatement ps = null;
		int tag = -1;
		System.out.println(sql);
		try {
			connection=DbcpUtil.getConnection();
			ps=connection.prepareStatement(sql);
			for(int i=0;i<obj.length;i++) {
				ps.setObject(i+1, obj[i]);
			}
			tag=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tag;
	}
	
}

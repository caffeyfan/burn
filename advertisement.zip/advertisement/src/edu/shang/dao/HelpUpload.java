package edu.shang.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.shang.bean.Login;
import edu.shang.bean.UploadFile;

@WebServlet("/helpUpload")
public class HelpUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 先检查客户是否登录，没有登录先提示登录
		//
		HttpSession session = request.getSession(true);
		Login login = (Login) session.getAttribute("login");
		boolean ok = true;
		if (login == null) {
			ok = false;
			response.sendRedirect("login.jsp");
		}
		if(ok){
			String logname = login.getLogname();
			System.out.println("用户登录"+logname);
			uploadFileMethod(request, response,logname);
		}
	}

	private void uploadFileMethod(HttpServletRequest request, HttpServletResponse response,String logname) {
		UploadFile uploadFile=new UploadFile();
		String backnews="";
		try {
			HttpSession session=request.getSession(true);
			request.setAttribute("upFile", uploadFile);
			String tempFileName=session.getId();
			//System.out.println(tempFileName);
			File f1=new File(tempFileName);
			FileOutputStream outputStream=new FileOutputStream(f1);
			InputStream in=request.getInputStream();
			
			int n;
			byte b[]=new byte[1000];
			while((n=in.read(b))!=-1) {
				outputStream.write(b, 0, n);
			}
			outputStream.close();
			in.close();
			RandomAccessFile random=new RandomAccessFile(f1, "r");
			int second=1;//读取上传文件的第二行，获得上传文件的名字
			String secondline=null;
			while(second<=2) {
				secondline=random.readLine();
				second++;
			}
			//获取第二行目录符号“\"最后出现的位置
			int position =secondline.lastIndexOf("\\");
			//获取文件名
			String fileName=secondline.substring(position+1,secondline.length()-1);
			byte cc[]=fileName.getBytes();
			fileName=new String (cc);
			fileName=fileName.replaceAll(" ", "");
			System.out.println(fileName);
			boolean isLetterOrDigit=true;
			//文字是否  有字母或是数字组成的
			String checkedStr=fileName.substring(0, fileName.indexOf("."));
			for(int i=0;i<checkedStr.length();i++) {
				char c=checkedStr.charAt(i);
				if(!((c<='z'&&c>='a')||(c<='Z'&&c>='A')||(c<='9'&&c>='0')))
				{ isLetterOrDigit=false;
					break;
				}
				}
//				if(isLetterOrDigit==false)
//				{ 
//					response.sendRedirect("upload.jsp");	
//				}
				String savedFileName=logname.concat(fileName);
				System.out.println(savedFileName);
				random.seek(0);
				long forthend=0;
				int forth=1;
				while((n=random.readByte())!=-1&&(forth<=4)){
					if(n=='\n')
					{ forthend=random.getFilePointer();
					forth++;
					}
				}
				//上传文件
				File dir=new File("E:\\eclipse\\workspace\\advertisement\\WebContent\\image");
				dir.mkdir();
				//删除用户曾经上传的文件
				File file[]=dir.listFiles();
				for(int k=0;k<file.length;k++){ 
					if(file[k].getName().startsWith(logname))
						file[k].delete();
				}
				File savingFile= new File(dir,savedFileName); //需要新保存的上传文件
				RandomAccessFile random2=new RandomAccessFile(savingFile, "rw");
				random.seek(random.length());
				long endposition=random.getFilePointer();
				long mark=endposition;
				int j=1;
				while((mark>=0)&&(j<=6))
				{ mark--;
				random.seek(mark);
				n=random.readByte();
				if(n=='\n')
				{
					endposition=random.getFilePointer();
					j++;
				}
				}
				random.seek(forthend);
				long startPoint=random.getFilePointer();
				while(startPoint<endposition-1)
				{ 
					n=random.readByte();
					random2.write(n);
					startPoint=random.getFilePointer();
				}
				random2.close();
				random.close();
				
				ADDao dao=new ADDao();
				int m=dao.select(logname).size();
				if(m>0) {
					if(isLetterOrDigit) {
						String sql = "update member set pic=? where logname=?";
						int mm=dao.update(sql,savedFileName, logname);
						if(mm>0) {
							backnews=fileName+"上传成功";
							uploadFile.setFileName(fileName);
							uploadFile.setSavedFileName(savedFileName);
							uploadFile.setBackNews(backnews);
							
						}
				}
				}
					f1.delete();
	}catch(Exception e){
		backnews=""+e;
		uploadFile.setBackNews(backnews);
	}
		System.out.println();
		try {
			request.getRequestDispatcher("showUploadMess.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
}


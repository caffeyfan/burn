package com.weixin.dao;

import org.junit.Test;

import com.weixin.bean.TopicBack;

public class TopicBackDaoTest {

	@Test
	public void test() {
		TopicBackDao dao=new TopicBackDao();
		dao.insert(new TopicBack(0, 2, 3,"", "你好的，我们是"));
	}
	@Test
	public void test2() {
		TopicBackDao dao=new TopicBackDao();
		dao.getTopics(2);
		System.out.println(dao.getTopics(2));
	}
}

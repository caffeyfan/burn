package com.weixin.dao;

import java.util.List;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.Food;

public class FoodDao extends MyBatisUtil{
	/**
	 * 获取个地点所有的美食
	 * @return
	 */
	public List<Food> getFoods(String placeId){
		
		getConnection();
		List<Food> foods=session.selectList("food.selectAll", placeId);
		closeSession();
		return foods;
	}
	public List<String> getTypes() {
		// TODO Auto-generated method stub
		getConnection();
		List<String> list=session.selectList("food.types");
		closeSession();
		return list;
	
		
	}
	
}

package com.weixin.dao;

import java.util.List;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.Major;
public class MajorDao extends MyBatisUtil{
	public Major getOneMajor(){
		getConnection();
		Major c=(Major)session.selectOne("major.selectone",1);
		closeSession();
		return c;
	}
	
	public List<Major> getAllMajor(String type){
		getConnection();
		List<Major> list=session.selectList("major.selectall",type);
		closeSession();
		return list;
	}

	public List<String> getTypes() {
		// TODO Auto-generated method stub
		getConnection();
		List<String> list=session.selectList("major.types");
		closeSession();
		return list;
	
		
	}
}

package com.weixin.dao;

import java.util.List;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.Place;

public class PlacedDao extends MyBatisUtil{
	public List<Place> getPlace(){
		getConnection();
		PlaceMapper mapper=session.getMapper(PlaceMapper.class);
		closeSession();
		return mapper.getPlaces();
	}
}

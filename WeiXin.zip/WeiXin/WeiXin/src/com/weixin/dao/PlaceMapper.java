package com.weixin.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.weixin.bean.Place;

public interface PlaceMapper{
	/**
	 * 查询所有的地点
	 */
	@Select("select * from foodPlace")
	public List<Place> getPlaces();
}

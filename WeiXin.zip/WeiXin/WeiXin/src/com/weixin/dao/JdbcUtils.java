package com.weixin.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;
//使用c3p0数据库连接池
//1首先加载jar包，2配置文件 3创建datasource
//只能使用静态代码块初始化datasource，并且初始化一次就好
//配置文件。c3p0-config.xml
public class JdbcUtils {
	private static ComboPooledDataSource datasource=null;
	static {
		datasource=new ComboPooledDataSource("mvcapp");
	}
	/**
	 *实现获取连接
	 * @return
	 */
	public static Connection getConnection() {
		Connection conn=null;
		try {
			conn=datasource.getConnection();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	/**
	 * 释放连接
	 * @param conn
	 */
	public static void releaseConnection(Connection conn) {
			try {
				if(conn!=null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}

package com.weixin.dao;

import java.util.List;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.TopicBack;

public class TopicBackDao extends MyBatisUtil{
	/**
	 * 添加回复贴
	 * @param topicback
	 */
	public void insert(TopicBack topicback) {
		getConnection();
		session.insert("topicback.add", topicback);
		session.commit();
		closeSession();
	}
	public List<TopicBack> getTopics(int topicId){
		getConnection();
		List<TopicBack> list=session.selectList("topicback.selectAll", topicId);
		closeSession();
		return list;
	}
}

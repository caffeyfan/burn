package com.weixin.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.Topic;
import com.weixin.bean.UserTopic;

public class TopicDao extends MyBatisUtil{
	/**
	 * 插入动态帖子
	 * @param topic
	 */
	public void insert(Topic topic) {
		getConnection();
		session.insert("topic.ins",topic);
		session.commit();
		closeSession();
		
	}
	/**
	 * 查询所有的动态帖子
	 */
	public List<UserTopic> getTopics(String type){
		getConnection();
		List<UserTopic> selectAll=session.selectList("topic.selectAll", type);
		closeSession();
		return selectAll;
	}
	/*
	 * 查询用户发布的帖子数目
	 */
	public long getTopicNum(int userId) {
		long num=0;
	
		getConnection();
		num=session.selectOne("topic.selectNum", userId);
		closeSession();
		return num;
	}
	/**
	 * 查询用户发的那些帖子
	 */
	public List<UserTopic> getTopics(int userId) {
		getConnection();
		List<UserTopic> topics=session.selectList("topic.topics", userId);
		closeSession();
		return topics;
	}
	/**
	 * 更新一帖子的点赞功能
	 */
	public void updateLike(int topicId) {
		getConnection();
		session.update("topic.click", topicId);
		session.commit();
		closeSession();
	}
	/**
	 * 收藏一个帖子
	 */
	public void CollectTopic(int userId,int topicId) {
		getConnection();
		//更新收藏数
		
		synchronized (session) {
			session.update("topic.collect", topicId);
			//加入收藏表
			Map<String, Integer> map = new HashMap<>();
			map.put("userId", userId);
			map.put("topicId", topicId);
			session.insert("collection.add", map);
		}
		session.commit();
		closeSession();
	}
	/**
	 * 
	 * 查询用户的收藏的帖子
	 */
	public List<UserTopic> getCollections(int userId){
		getConnection();
		List<UserTopic> topics=session.selectList("collection.selectAll", userId);
		session.commit();
		closeSession();
		return topics;
	}
	public UserTopic getTopic(int topicId){
		getConnection();
		UserTopic selectAll=session.selectOne("topic.selectOne", topicId);
		closeSession();
		return selectAll;
	}
}

package com.weixin.dao;

import java.util.List;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.Lab;

public class LabDao extends MyBatisUtil{
	//��ѯ����
	public List<Lab> getAllLab(String type){
		getConnection();
		List<Lab> list=session.selectList("lab.selectall",type);
		for(Lab lab:list){
			System.out.println(lab);
		}
		closeSession();
		return list;
	}
	public List<String> getTypes(){
		getConnection();
		List<String> list=session.selectList("lab.types");
		
		closeSession();
		return list;
	}
}

package com.weixin.dao;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;



public class DAO<T>{
	private Class<T> clazz=null;
	private QueryRunner queryrunner=null;
	//初始化，通过反射来获取类型
	public DAO() {
		//获取泛型的对象
		Type type=getClass().getGenericSuperclass();//获取当前运行时类的带泛型的父类
		//如果 type是带参数的，强转
		if(type instanceof ParameterizedType) {
			Type[] types=((ParameterizedType) type).getActualTypeArguments();
			if(types!=null&&types.length>0) {
				clazz=(Class<T>) types[0];
			}
		}
		queryrunner=new QueryRunner();
	}
	/**
	 * 更新操作，包括添加，修改，删除操作
	 * @param sql  插入语句
	 * @param args 插入的参数
	 * @return 
	 */
	public int update(String sql,Object...args) {
		Connection conn=null;
		int i=0;
		try {
			conn=JdbcUtils.getConnection();
			i=queryrunner.update(conn, sql, args);
			System.out.println("dao的更新");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JdbcUtils.releaseConnection(conn);
		}
		return i;
	}
	/**
	 * 查询，只返回一条记录
	 * @param sql
	 * @param args
	 * @return
	 */
	public T select(String sql,Object...args) {
		Connection conn=null;
		T t=null;
		try {
			conn=JdbcUtils.getConnection();
			t=queryrunner.query(conn, sql, new BeanHandler<>(clazz), args);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JdbcUtils.releaseConnection(conn);
		}
			return t;
	}
	/**
	 * 查询所有的记录
	 * @param sql
	 * @param args
	 * @return
	 */
	public List<T> selectAll(String sql,Object...args){
		Connection conn=null;
		List<T> t=null;
		try {
			conn=JdbcUtils.getConnection();
			t=queryrunner.query(conn, sql, new BeanListHandler<>(clazz), args);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JdbcUtils.releaseConnection(conn);
		}
			return t;
	}
	/**
	 * 查询具体的内容
	 * @param sql
	 * @param args
	 * @return
	 */
	public <E>E selectvalue(String sql,Object...args) {
		Connection conn=null;
		E ea=null;
		try {
			conn=JdbcUtils.getConnection();
			ea=(E) queryrunner.query(conn, sql, new ScalarHandler(), args);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JdbcUtils.releaseConnection(conn);
		}
			return ea;
	}
}

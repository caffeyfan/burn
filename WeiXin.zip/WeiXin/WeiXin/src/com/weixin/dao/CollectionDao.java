package com.weixin.dao;

import com.mybatisUtil.MyBatisUtil;

public class CollectionDao extends MyBatisUtil{
	/**
	 * 查询收藏的数目
	 */
}

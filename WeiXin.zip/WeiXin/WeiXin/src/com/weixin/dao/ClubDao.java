package com.weixin.dao;

import java.util.List;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.club;

public class ClubDao extends MyBatisUtil{
	
	public List<club> getAllClub(String type){
		
		getConnection();
		List<club> list=session.selectList("club.selectall",type);
		session.commit();
		closeSession();
		return list;
	}

	public List<String> getTypes() {
		// TODO Auto-generated method stub
		getConnection();
		List<String> list=session.selectList("club.types");
		closeSession();
		return list;
	
		
	}
}

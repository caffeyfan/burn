package com.weixin.dao;

import com.mybatisUtil.MyBatisUtil;
import com.weixin.bean.User;

public class UserDao extends MyBatisUtil{
	/**
	 * 插入用户信息,返回插入的id
	 * @param user
	 */
	public int insert(User user) {
		getConnection();
		int id=session.insert("user.addUser", user);
		session.commit();
		
		closeSession();
		return id;
	}
	/**
	 * 判断该用户是否存在,存在返回用户的id，不存在返回0
	 * @param id
	 * @return
	 */
	
	/**
	 * 
	 * 查询用户的id
	 */
	public User getUser(String userName) {
		getConnection();
		User user=session.selectOne("user.selectuser", userName);
	    closeSession();
	    return user;
	}
	/**
	 * 获取用户收藏数
	 */
	public long getCollectNum(int userId) {
		long num=0;
	
		getConnection();
		num=session.selectOne("collection.selectNum", userId);
		
		closeSession();
		return num;
	}
}

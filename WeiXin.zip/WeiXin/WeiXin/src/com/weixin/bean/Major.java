package com.weixin.bean;

public class Major {
	private int MajorId;
	private String name;
	private String introduction;
	private String school;
	private String type;
	public int getMajorId() {
		return MajorId;
	}
	public void setMajorId(int majorId) {
		MajorId = majorId;
	}
	public String getName() {
		return name;
	}
	@Override
	public String toString() {
		return "Major [MajorId=" + MajorId + ", name=" + name + ", introduction=" + introduction + ", school=" + school
				+ ", type=" + type + "]";
	}
	public void setName(String name) {
		this.name = name;
	}
	public Major() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}

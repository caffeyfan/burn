package com.weixin.bean;

public class User {
	private int userId;
	private String userName;
	private String pic;
	public User(int id, String name, String pic) {
		super();
		this.userId = id;
		this.userName = name;
		this.pic = pic;
	}
	public int getuserId() {
		return userId;
	}
	public void setuserId(int id) {
		this.userId = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String name) {
		this.userName = name;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

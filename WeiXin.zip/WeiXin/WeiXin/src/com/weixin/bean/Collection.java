package com.weixin.bean;

public class Collection {
	//收藏表
	private  int id;
	private  int userId;
	private int topicId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}
	public Collection() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Collection(int id, int userId, int topicId) {
		super();
		this.id = id;
		this.userId = userId;
		this.topicId = topicId;
	}
	
}

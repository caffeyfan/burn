package com.weixin.bean;

public class TopicBack {
	private int id;//帖子id
	private int userId;//回复人
	private String userName;
	private String pic;
	private int topicId;//回复的帖子
	private String backDate;
	private String backContent;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getBackDate() {
		return backDate;
	}
	public void setBackDate(String backDate) {
		this.backDate = backDate;
	}
	public String getBackContent() {
		return backContent;
	}
	public void setBackContent(String backContent) {
		this.backContent = backContent;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public TopicBack(int id, int topicId, int userId, String backDate,String content) {
		super();
		this.id = id;
		this.topicId = topicId;
		this.userId = userId;
		this.backContent = content;
		this.backDate=backDate;
	}
	public TopicBack() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TopicBack [id=" + id + ", topicId=" + topicId + ", userId=" + userId + ", content=" +backContent + "]";
	}
	
}

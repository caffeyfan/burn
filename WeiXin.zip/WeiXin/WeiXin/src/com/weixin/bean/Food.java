package com.weixin.bean;

public class Food {
	private int foodId;
	private String place;
	private String placeId;
	private String foodName;
	
	public Food(int foodId, String place, String placeId, String foodName) {
		super();
		this.foodId = foodId;
		this.place = place;
		this.placeId = placeId;
		this.foodName = foodName;
	
	}
	public String getPlaceId() {
		return placeId;
	}
	public void setPlaceId(String placeId) {
		this.placeId = placeId;
	}
	
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}

	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	
	public Food() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}

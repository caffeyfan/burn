package com.weixin.bean;

public class UserTopic {
	private int userId;
	private String userName;
	private String pic;
	private int topicId;
	private String title;
	private String content;
	private String publishDate;
	private String type;
	private int likeNum;
	private int collectNum;
	private int reviewNum;
	
	public int getReviewNum() {
		return reviewNum;
	}
	public void setReviewNum(int reviewNum) {
		this.reviewNum = reviewNum;
	}
	public UserTopic() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserTopic(int userId, String userName, String pic, int topicId, String title, String content,
			String publishDate, String type, int likeNum, int collectNum, int reviewNum) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.pic = pic;
		this.topicId = topicId;
		this.title = title;
		this.content = content;
		this.publishDate = publishDate;
		this.type = type;
		this.likeNum = likeNum;
		this.collectNum = collectNum;
		this.reviewNum = reviewNum;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getLikeNum() {
		return likeNum;
	}
	public void setLikeNum(int likeNum) {
		this.likeNum = likeNum;
	}
	public int getCollectNum() {
		return collectNum;
	}
	public void setCollectNum(int collectNum) {
		this.collectNum = collectNum;
	}
	@Override
	public String toString() {
		return "UserTopic [userId=" + userId + ", userName=" + userName + ", pic=" + pic + ", topicId=" + topicId
				+ ", title=" + title + ", content=" + content + ", publishDate=" + publishDate + ", type=" + type
				+ ", likeNum=" + likeNum + ", collectNum=" + collectNum + "]";
	}
	
}

package com.weixin.bean;

public class club {

	private int clubId;
	private String name;
	private String introduction;
	private String school;
	private String type;
	
	public int getClubid() {
		return clubId;
	}
	public void setClubid(int clubid) {
		this.clubId = clubid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "club [clubId=" + clubId + ", name=" + name + ", introduction=" + introduction + ", school=" + school
				+ ", type=" + type + "]";
	}
	
}

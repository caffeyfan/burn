package com.weixin.bean;

public class Topic {
	private int topicId;
	private int userId;
	private String title;
	private String content;
	private String publishDate;
	private String type;//什么类型的帖子
	private int likeNum;//点赞数
	private int collectNum;
	private int reviewNum;
	public int getReviewNum() {
		return reviewNum;
	}
	public void setReviewNum(int reviewNum) {
		this.reviewNum = reviewNum;
	}
	public int getLikeNum() {
		return likeNum;
	}
	public void setLikeNum(int likeNum) {
		this.likeNum = likeNum;
	}
	public int getCollectNum() {
		return collectNum;
	}
	public void setCollectNum(int collectNum) {
		this.collectNum = collectNum;
	}
	
	public Topic(int topicId, int userId, String title, String content, String publishDate, String type, int likeNum,
			int collectNum, int reviewNum) {
		super();
		this.topicId = topicId;
		this.userId = userId;
		this.title = title;
		this.content = content;
		this.publishDate = publishDate;
		this.type = type;
		this.likeNum = likeNum;
		this.collectNum = collectNum;
		this.reviewNum = reviewNum;
	}
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Topic() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Topic [topicId=" + topicId + ", userId=" + userId + ", title=" + title + ", content=" + content
				+ ", publishDate=" + publishDate + ", type=" + type + ", likeNum=" + likeNum + ", collectNum="
				+ collectNum + "]";
	}
	
	
}

package com.weixin.bean;

public class Place {
	private int placeId;
	private String place;
	public int getPlaceId() {
		return placeId;
	}
	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public Place(int placeId, String place) {
		super();
		this.placeId = placeId;
		this.place = place;
	}
	@Override
	public String toString() {
		return "Place [placeId=" + placeId + ", place=" + place + "]";
	}
	
}

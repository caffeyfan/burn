package com.weixin.bean;
//���־û��ࣩLab �� pojo 
public class Lab {
	
	private String name;
	private String school;
	private String type;
	private String introduction;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	@Override
	public String toString() {
		return "Lab [name=" + name + ", school=" + school + ", type=" + type + ", introduction="
				+ introduction + "]";
	}
}

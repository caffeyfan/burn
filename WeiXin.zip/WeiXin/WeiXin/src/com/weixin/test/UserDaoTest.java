package com.weixin.test;

import org.junit.Test;

import com.weixin.bean.User;
import com.weixin.dao.UserDao;

public class UserDaoTest {
    //已测试
	@Test
	public void testInsert() {
		UserDao dao=new UserDao();
		User user=new User(0, "幻化", "加快");
		int i=dao.insert(user);
		System.out.println(i);
	}
    //已测试
	@Test
	public void testIsHave() {
		UserDao dao=new UserDao();
		User user=dao.getUser("zhangsan");
		System.out.println(user);
	}

}

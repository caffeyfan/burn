package com.weixin.test;

import java.util.List;

import org.junit.Test;

import com.weixin.bean.Food;
import com.weixin.dao.FoodDao;

public class TestFoodDao {
	@Test
	public void testGetFoods() {
		FoodDao dao=new FoodDao();
		List<Food> foods=dao.getFoods("3");
		System.out.println(foods);
		
	}
}

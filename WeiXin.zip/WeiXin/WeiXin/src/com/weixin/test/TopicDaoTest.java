package com.weixin.test;

import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.Test;

import com.weixin.bean.UserTopic;
import com.weixin.dao.PlacedDao;
import com.weixin.dao.TopicDao;

public class TopicDaoTest {
	//已经测试
	TopicDao dao=new TopicDao();
	@Test
	public void testInsert(){
		java.util.Date date=new java.util.Date();
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
		String date1=simpleDateFormat.format(date);
		System.out.println(date1);
		//Topic topic=new Topic(0, 2, "怎么夕阳", "不需要他夺得，欢迎光临",date1, "美食",3,3);
		//dao.insert(topic);
	}
	//OK
	@Test
	public void testGetTopics() {
		List<UserTopic> list=dao.getTopics("美食");
		System.out.println(list);
		
	}
	//OK
	@Test
	public void testGetTopicNum() {
		long m=dao.getTopicNum(1);
		System.out.println(m);
	}
	//OK
	@Test
	public void testUpdateLike() {
		dao.updateLike(3);
	}
	//OK
	@Test
	public void testCollectTopic() {
		dao.CollectTopic(2, 7);
	}
	//OK
	@Test
	public void testGetCollections() {
		List<UserTopic> list=dao.getCollections(2);
		for(UserTopic t:list) {
			System.out.println(t);
		}
	}
	@Test
	public void get() {
		PlacedDao dao=new PlacedDao();
		System.out.println(dao.getPlace());
	}
	@Test
	public void getTopic() {
		System.out.println(dao.getTopics(3));
	}
}

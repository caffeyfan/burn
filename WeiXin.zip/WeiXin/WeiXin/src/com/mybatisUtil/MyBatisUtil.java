package com.mybatisUtil;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MyBatisUtil {
	private static SqlSessionFactoryBuilder  sfb=null;
	private static SqlSessionFactory sf=null;
	protected SqlSession session;
	static{
		try {
			Reader reader=Resources.getResourceAsReader("mybatis-config.xml");
			sfb=new SqlSessionFactoryBuilder();
			sf=sfb.build(reader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//��session
	public void getConnection(){
		session=sf.openSession();
	}
	
	//�ر�session
	public void closeSession(){
		session.close();
	}
}
package com.servlet;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.weixin.bean.Topic;
import com.weixin.bean.TopicBack;
import com.weixin.bean.User;
import com.weixin.bean.UserTopic;
import com.weixin.dao.TopicBackDao;
import com.weixin.dao.TopicDao;
import com.weixin.dao.UserDao;

/**
 * Servlet implementation class TopicServlet
 */
@WebServlet("/topicServlet")
public class TopicServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String method=request.getParameter("method");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
			Method method2;
			try {
				method2 = getClass().getDeclaredMethod(method, HttpServletRequest.class,HttpServletResponse.class);
				method2.setAccessible(true);
				method2.invoke(this, request,response);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

		
	}
	/**
	 * 获取回复
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void getBackTopics(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TopicBackDao dao=new TopicBackDao();
		String string=request.getParameter("topicId");
		List<TopicBack> lsit=dao.getTopics(Integer.parseInt(string));
		response.getWriter().print(MakeJson(lsit));
	}
	
	protected void getTopic(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TopicDao dao=new TopicDao();
		String string=request.getParameter("topicId");
		UserTopic lsit=dao.getTopic(Integer.parseInt(string));
		response.getWriter().print(MakeJson(lsit));
	}
	protected void publish(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TopicDao dao=new TopicDao();
		String user=request.getParameter("userName");
		UserDao dao2=new UserDao();
		int userId=dao2.getUser(user).getuserId();
		String title=request.getParameter("title");
		
		String content=request.getParameter("content");
		String type1=request.getParameter("type");
		int id=Integer.parseInt(type1);
		String[] strings=new String[] {"food","club","lab","major","mine"};
		String publishDate=null;
		Date date=new Date();
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		publishDate=format.format(date);
		Topic Topic=new Topic(0, userId, title, content, publishDate, strings[id], 0, 0, 0);
		dao.insert(Topic);
		
	}
	protected void addBack(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TopicBackDao dao=new TopicBackDao();
		String backContent=request.getParameter("backContent");
		String userName=request.getParameter("nickName");
		UserDao userDao=new UserDao();
		User user=userDao.getUser(userName);
		Date date=new Date();
		System.out.println(date);
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
		String dat=simpleDateFormat.format(date);
		String string=request.getParameter("topicId");
		TopicBack topicback=new TopicBack(0, Integer.parseInt(string), user.getuserId(),dat, backContent);
		dao.insert(topicback);
		List<TopicBack> lsit=dao.getTopics(Integer.parseInt(string));
		
		response.getWriter().print(MakeJson(lsit));
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	//构建字符串的方
		public String MakeJson(Object object) throws JsonGenerationException, JsonMappingException, IOException {
			ObjectMapper mapper=new ObjectMapper();
			String value=mapper.writeValueAsString(object);
			return value;
		}

}

package com.servlet;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.weixin.bean.Food;
import com.weixin.bean.User;
import com.weixin.bean.UserTopic;
import com.weixin.dao.FoodDao;
import com.weixin.dao.TopicDao;
import com.weixin.dao.UserDao;

/**
 * Servlet implementation class FoodServlet
 */
@WebServlet("/foodServlet")
public class FoodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String method=request.getParameter("method");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
			Method method2;
			try {
				method2 = getClass().getDeclaredMethod(method, HttpServletRequest.class,HttpServletResponse.class);
				method2.setAccessible(true);
				method2.invoke(this, request,response);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
	}

	protected void getFoods(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idString=request.getParameter("id");
		int placeId=Integer.parseInt(idString);
		FoodDao dao=new FoodDao();
		String type=dao.getTypes().get(placeId);
		List<Food> foods=dao.getFoods(type);
		
		response.getWriter().print(MakeJson(foods));
		
	}
	//获取用户信息
	protected void getUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("nickName");
		String pic=request.getParameter("avatarUrl");
		long topicNum=0;
		long collectNum=0;
		System.out.println(userName);
		UserDao dao=new UserDao();
		
		//查询是否存在该用户
		User user=dao.getUser(userName);
		if(user==null) {
			dao.insert(new User(0, userName, pic));
		}else {
			int userId=user.getuserId();
			System.out.println(userId);
			//查询他的发帖数和收藏数
			TopicDao topicDao=new TopicDao();
			//发帖数
			topicNum=topicDao.getTopicNum(userId);
			System.out.println("topicnum"+topicNum);
			collectNum=dao.getCollectNum(userId);
			Map<String, Long> map=new HashMap<>();
			map.put("topicNum", topicNum);
			map.put("collectNum", collectNum);
			
			response.getWriter().print(MakeJson(map));
		}
		
	}
	/**
	 * 获取用户收藏的帖子
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void getCollection(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("nickName");
		UserDao dao=new UserDao();
		int userId=dao.getUser(userName).getuserId();
		TopicDao topicDao=new TopicDao();
		List<UserTopic> list=topicDao.getCollections(userId);
		response.getWriter().print(MakeJson(list));;
	}
	
	/**
	 * 获取yoonghu发布的帖子
	 * @param request
	 * @param response
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	protected void getPublish(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("nickName");
		UserDao dao=new UserDao();
		int userId=dao.getUser(userName).getuserId();
		TopicDao topicDao=new TopicDao();
		List<UserTopic> list=topicDao.getTopics(userId);
		response.getWriter().print(MakeJson(list));;
	}
	//获取所有的话题
	public void getTopics(HttpServletRequest request,HttpServletResponse response) throws JsonGenerationException, JsonMappingException, IOException {
		
		TopicDao dao=new TopicDao();
		String type=request.getParameter("type");
		List<UserTopic> list=dao.getTopics(type);
		response.getWriter().println(MakeJson(list));
	}
	
	//构建字符串的方
	public String MakeJson(Object object) throws JsonGenerationException, JsonMappingException, IOException {
		ObjectMapper mapper=new ObjectMapper();
		String value=mapper.writeValueAsString(object);
		return value;
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
